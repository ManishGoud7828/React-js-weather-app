#!/usr/bin/env sh
set -x
npm run build
set +x
