import Database from "./database";

export let db = new Database();


